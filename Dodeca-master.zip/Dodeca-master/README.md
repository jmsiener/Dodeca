# Dodeca
An Open Hardware, DIY Eurorack extensible platform allowing the configuration of custom MIDI outputs. 
